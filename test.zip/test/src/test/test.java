package test;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.LinkedList;
import java.util.*;
import javax.imageio.ImageIO;
import javax.swing.*;


class GraphByMatrix {  
    public static final boolean UNDIRECTED_GRAPH = false;//����ͼ��־  
    public static final boolean DIRECTED_GRAPH = true;//����ͼ��־  
  
    public static final boolean ADJACENCY_MATRIX = true;//�ڽӾ���ʵ��  
    public static final boolean ADJACENCY_LIST = false;//�ڽӱ�ʵ��  
  
    public static final int MAX_VALUE = Integer.MAX_VALUE;  
    private boolean graphType;  
    private boolean method;  
    private int vertexSize;  
    private int matrixMaxVertex;  
  
    //�洢���ж�����Ϣ��һά����  
    private Object[] vertexesArray;  
    //�洢ͼ�ж���֮�������ϵ�Ķ�ά����,���ߵĹ�ϵ  
    private int[][] edgesMatrix;  
  
    // ��¼��i���ڵ��Ƿ񱻷��ʹ�  
    private boolean[] visited;  
  
    /** 
     * @param graphType ͼ�����ͣ�����ͼ/����ͼ 
     * @param method    ͼ��ʵ�ַ�ʽ���ڽӾ���/�ڽӱ� 
     */  
    public GraphByMatrix(boolean graphType, boolean method, int size) {  
        this.graphType = graphType;  
        this.method = method;  
        this.vertexSize = 0;  
        this.matrixMaxVertex = size;  
  
        if (this.method) {  
            visited = new boolean[matrixMaxVertex];  
            vertexesArray = new Object[matrixMaxVertex];  
            edgesMatrix = new int[matrixMaxVertex][matrixMaxVertex];  
  
            //��������г�ʼ���������û�б߹�����ֵΪInteger���͵����ֵ  
            for (int row = 0; row < edgesMatrix.length; row++) {  
                for (int column = 0; column < edgesMatrix.length; column++) {  
                    edgesMatrix[row][column] = MAX_VALUE;  
                }  
            }  
  
        }  
    }  
  
    /********************���·��****************************/  
    //����һ�����㵽����һ���������̾���  
    public void Dijkstra(Object obj) throws Exception {  
        Dijkstra(getVertexIndex(obj));  
    }  
    public int[] Dijkstra(int v0 , int v1 , Frame f) {  
        int[] dist = new int[matrixMaxVertex];  
        int[] prev = new int[matrixMaxVertex];  
  
        //��ʼ��visited��dist��path  
        for (int i = 0; i < vertexSize; i++) {  
            //һ��ʼ�ٶ�ȡֱ��·�����  
            dist[i] = edgesMatrix[v0][i];  
            visited[i] = false;  
  
            //ֱ������µ�����ɵ���ǳ�����  
            if (i != v0 && dist[i] < MAX_VALUE)  
                prev[i] = v0;  
            else  
                prev[i] = -1; //��ֱ��·��  
        }  
  
        //��ʼʱԴ��v0��visited������ʾv0 ��v0�����·���Ѿ��ҵ�  
        visited[v0] = true;  
  
        // �������辭��һ������ת�����������,���Щ,��֤֮  
        // �ټ��辭����������ת,�����Щ,��֤֮,.....  
        // ֱ����������п��ܵ���ת��  
        int minDist;  
        int v = 0;  
        for (int i = 1; i < vertexSize; i++) {  
            //��һ������������ɵ�,�±�װ�� v  
            minDist = MAX_VALUE;  
  
            for (int j = 0; j < vertexSize; j++) {  
                if ((!visited[j]) && dist[j] < minDist) {  
                    v = j;                             // ���ɶ���j��ת��������  
                    minDist = dist[j];  
                }  
            }  
            visited[v] = true;  
  
            /*����v����S����v0����v��������·��Ϊmin. 
              �ٶ���v0��v������vֱ��������㣬���µ�ǰ���һ�����ɵ㼰����*/  
            for (int j = 0; j < vertexSize; j++) {  
                if ((!visited[j]) && edgesMatrix[v][j] < MAX_VALUE) {  
  
                    if (minDist + edgesMatrix[v][j] <= dist[j]) {  
                        //����ྭ��һ��v�㵽��j��� ���·������Ҫ��,�͸���  
                        dist[j] = minDist + edgesMatrix[v][j];  
  
                        prev[j] = v;                    //���ɵ�����  
                    }  
  
                }  
            }  
  
        }  
  
        for (int i = 1; i < matrixMaxVertex; i++) {
        	if(i == v1) {
        		//System.out.println("**" + vertexesArray[v0] + "-->" +vertexesArray[i] + " �����·���ǣ�" + dist[i]);
        		String s = "**" + vertexesArray[v0] + "-->" +vertexesArray[i] + " �����·���ǣ�" + dist[i] ;
        		System.out.println(s) ;
        	}
        }
        //int []result = {0,1,2,3,4,5,6,7,8,9,10}  ;
        int []result = new int[1000] ;
        int []result1 = new int[1000] ;
        /*for(int i = 0 ; i < result.length ;i ++) {
        	result[i] = -1 ;
        }*/
        result[0] = v1;
        int temp = prev[v1] ;
        //System.out.println("1111111111 " + v1 + "  " + temp);
        int tot = 1 ;
        System.out.println(v0 + " V0");
        while(temp != v0)
        {
            result[tot] = temp;
            tot++;
            temp = prev[temp];
        }
        int tot1 = 0 ;
        System.out.println("22222222");
        for(int i = tot-1 ; i >=0 ; i -- ) {
        	System.out.print(result[i] + " ");
        	result1[tot1] = result[i] ;
        	tot1 ++ ;
        }        	
        System.out.println("");
        return result1;
    }  
  
    //��ȡ����ֵ���������Ӧ������  
    private int getVertexIndex(Object obj) throws Exception {  
        int index = -1;  
        for (int i = 0; i < vertexSize; i++) {  
            if (vertexesArray[i].equals(obj)) {  
                index = i;  
                break;  
            }  
        }  
        if (index == -1) {  
            throw new Exception("û�����ֵ��");  
        }  
  
        return index;  
    }  
  
    /** 
     * ��Դ���·���㷨�����ڼ���һ���ڵ㵽����!!���нڵ�!!�����·�� 
     */  
    public void Dijkstra2(int v0) {  
        // LinkedListʵ����Queue�ӿ� FIFO  
        Queue<Integer> queue = new LinkedList<Integer>();  
        for (int i = 0; i < vertexSize; i++) {  
            visited[i] = false;  
        }  
  
        //���ѭ����Ϊ��ȷ��ÿ�����㶼��������  
        for (int i = 0; i < vertexSize; i++) {  
            if (!visited[i]) {  
                queue.add(i);  
                visited[i] = true;  
  
                while (!queue.isEmpty()) {  
                    int row = queue.remove();  
                    System.out.print(vertexesArray[row] + "-->");  
  
                    for (int k = getMin(row); k >= 0; k = getMin(row)) {  
                        if (!visited[k]) {  
                            queue.add(k);  
                            visited[k] = true;  
                        }  
                    }  
  
                }  
            }  
        }  
    }  
  
    private int getMin( int row) {  
        int minDist = MAX_VALUE;  
        int index = 0;  
        for (int j = 0; j < vertexSize; j++) {  
            if ((!visited[j]) && edgesMatrix[row][j] < minDist) {  
                minDist = edgesMatrix[row][j];  
                index = j;  
            }  
        }  
        if (index == 0) {  
            return -1;  
        }  
        return index;  
    }  
  
    public boolean addVertex(Object val) {  
        assert (val != null);  
        vertexesArray[vertexSize] = val;  
        vertexSize++;  
        return true;  
    }  
  
    public boolean addEdge(int vnum1, int vnum2, int weight) {  
        assert (vnum1 >= 0 && vnum2 >= 0 && vnum1 != vnum2 && weight >= 0);  
  
        //����ͼ  
        if (graphType) {  
            edgesMatrix[vnum1][vnum2] = weight;  
  
        } else {  
            edgesMatrix[vnum1][vnum2] = weight;  
            edgesMatrix[vnum2][vnum1] = weight;  
        }  
  
        return true;  
    }  
  
}  


class MyPanel extends JPanel{
	Image image = null;
	public void paint(Graphics g){
		try {
			image = ImageIO.read(new File("F:\\java����\\test\\TIMͼƬ20180611220039.png"));
			g.drawImage(image, 0, 0, 719, 708, null);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}

class jiemian extends Frame
{
	public String s = "" ;
	public int [] ans = new int[1000] ;
	public JLabel result = new JLabel(s) ;
	public jiemian()
	{
		//String[] place= {"1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17"} ;
		String[] place= {"ͨ��","���","����","˳��","����ʪ��",
                "���","����","������","��ʢ","�ɻ���",
                "��վ","�Ĳ���","����","˫����","���ؽ�",
                "������","������"} ;
		Frame f = new Frame();
		//f.setLayout(new GridLayout(3,1));
		//f.setLayout(new FlowLayout());
		f.setLayout(new BorderLayout());
		f.setSize(800, 900);
		Panel p1 = new Panel(new GridLayout(1,3));
		JComboBox placeComboBox1 = new JComboBox(place) ;
		JComboBox placeComboBox2 = new JComboBox(place) ;
		//JList placeList1 = new JList(place) ;
		//JList placeList2 = new JList(place) ;
		JButton bt = new JButton("Begin");
		//Dimension preferredSize = new Dimension(100,100);
		//bt.setPreferredSize(preferredSize );
		p1.add(placeComboBox1) ;
		p1.add(placeComboBox2) ;
		p1.add(bt);
		//f.setBounds(0, 0, 400, 300);
		//p1.add(placeList1) ;
		//p1.add(placeList2) ;
		//p1.add(bt) ;   
		bt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//String start = placeComboBox1.getSelectedItem().toString() ;
				//String end = placeComboBox2.getSelectedItem().toString() ;
				int start = placeComboBox1.getSelectedIndex() ;
				int end = placeComboBox2.getSelectedIndex() ;
				System.out.println(start + "   " + end);
				GraphByMatrix graph = new GraphByMatrix(false, true, 17);
				graph.addVertex("1");  
			    graph.addVertex("2");  
			    graph.addVertex("3");  
			    graph.addVertex("4");  
			    graph.addVertex("5");  
			    graph.addVertex("6");  
			    graph.addVertex("7");  
			    graph.addVertex("8");  
			    graph.addVertex("9");  
			    graph.addVertex("10");  
			    graph.addVertex("11");  
			    graph.addVertex("12");  
			    graph.addVertex("13");  
			    graph.addVertex("14");  
			    graph.addVertex("15");  
			    graph.addVertex("16");  
			    graph.addVertex("17"); 
			    
			    graph.addEdge(0, 1, 1);
			    graph.addEdge(0, 2, 1);
			    graph.addEdge(1, 3, 3);
			    graph.addEdge(2, 3, 3);
			    graph.addEdge(1, 4, 8);
			    graph.addEdge(4 ,5 ,6);
			    graph.addEdge(3, 5, 2);
			    graph.addEdge(2, 7, 7);
			    graph.addEdge(4, 6, 4);
			    graph.addEdge(5, 7, 4);
			    graph.addEdge(5, 8, 2);
			    graph.addEdge(7, 8, 4);
			    graph.addEdge(7, 10, 3);
			    graph.addEdge(6, 9, 3);
			    graph.addEdge(8, 9, 5);
			    graph.addEdge(9, 11, 2);
			    graph.addEdge(8, 12, 5);
			    graph.addEdge(7, 13, 2);
			    graph.addEdge(10, 13, 2);
			    graph.addEdge(12, 13, 2);
			    graph.addEdge(11, 12, 2);
			    graph.addEdge(11, 14, 2);
			    graph.addEdge(14, 15, 10);
			    graph.addEdge(11, 16, 3);
			    graph.addEdge(13, 16, 6) ;
			    graph.addEdge(15, 16, 9);
			    
			    ans = graph.Dijkstra(start,end,f); 
			    int[] arr = graph.Dijkstra(start,end,f); 
			    String s = " --> " + place[arr[0]];
		        System.out.print(arr[0] + " ");
			    for(int i = 1 ; i < arr.length  ; i ++ ) {
			    	if(arr[i] > 0) { 
			    		System.out.print(arr[i] + " ");
			    		s = s + " --> " + place[arr[i]] ;
			    	}
		        }        	
		        System.out.println("");
		        System.out.println(s);
		        String a = "result" ;
		        result.setFont(new Font("����",Font.BOLD,20));
		        result.setText(s);
			}
			
		});
		MyPanel mp = new MyPanel();
		//String a = "result" ;
		//JLabel result = new JLabel(s);
		//result.setFont(new Font(null , Font.PLAIN,25));
		//f.add(p1) ;
		//f.add(mp);
		f.add(p1,BorderLayout.NORTH);
		f.add(mp,BorderLayout.CENTER);
		//String s =  ans[0] + " ";
		//String s = place[ans[0]] + " " ;
        //System.out.print(ans[0] + " ");
	    /*for(int i = 1 ; i < ans.length  ; i ++ ) {
	    	if(ans[i] > 0) { 
	    		//System.out.print(place[ans[i]] + " ");
	    		s = s + place[ans[i]] + " " ;
	    	}
        }     	
	    System.out.println(s);*/
	    //JLabel result = new JLabel(s) ;
		//f.add(result) ;
		f.add(result, BorderLayout.SOUTH);
		f.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
		f.setVisible(true);
	}
}

public class test {
	public static void main(String args[])
	{
		jiemian jiemain1 = new jiemian();
	}
}
